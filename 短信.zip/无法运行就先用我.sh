pkg install vim
pkg install vim-python
cd /data/data/com.termux/files/home
chmod 777 先运行我.sh
./先运行我.sh
rm -rf /data/data/com.termux/files/home/无法运行就先用我.sh